let jogador;
let frutas = [];
let legumes = [];
let cidade;

function setup() {
  createCanvas(800, 600);
  jogador = {
    x: 100,
    y: height / 2,
    w: 50,
    h: 50,
    speed: 5,
    inventario: []
  };
  cidade = {
    x: width - 100,
    y: height / 2,
    w: 100,
    h: 100
  };
  for (let i = 0; i < 10; i++) {
    frutas.push({
      x: random(200, 400),
      y: random(height),
      w: 20,
      h: 20
    });
    legumes.push({
      x: random(200, 400),
      y: random(height),
      w: 20,
      h: 20
    });
  }
}

function draw() {
  background(135, 206, 235); // Céu azul
  drawCampo();
  drawCidade();
  drawJogador();
  drawFrutas();
  drawLegumes();
  checkCollisions();
  displayInventario();
}

function drawCampo() {
  fill(34, 139, 34); // Verde
  rect(0, 0, width / 2, height);
}

function drawCidade() {
  fill(128); // Cinza
  rect(width / 2, 0, width / 2, height);
  fill(255);
  textSize(36);
  text("Cidade", width - 150, height / 2);
}

function drawJogador() {
  fill(255, 0, 0); // Vermelho
  rect(jogador.x, jogador.y, jogador.w, jogador.h);
}

function drawFrutas() {
  fill(255, 255, 0); // Amarelo
  for (let fruta of frutas) {
    ellipse(fruta.x, fruta.y, fruta.w, fruta.h);
  }
}

function drawLegumes() {
  fill(0, 255, 0); // Verde
  for (let legume of legumes) {
    ellipse(legume.x, legume.y, legume.w, legume.h);
  }
}

function checkCollisions() {
  // Verificar colisões com frutas
  for (let fruta of frutas) {
    if (dist(jogador.x, jogador.y, fruta.x, fruta.y) < jogador.w / 2 + fruta.w / 2) {
      jogador.inventario.push("Fruta");
      frutas.splice(frutas.indexOf(fruta), 1);
    }
  }
  
  // Verificar colisões com legumes
  for (let legume of legumes) {
    if (dist(jogador.x, jogador.y, legume.x, legume.y) < jogador.w / 2 + legume.w / 2) {
      jogador.inventario.push("Legume");
      legumes.splice(legumes.indexOf(legume), 1);
    }
  }
  
  // Verificar entrega na cidade
  if (jogador.x + jogador.w > cidade.x) {
    alert("Entrega realizada com sucesso!");
    jogador.inventario = [];
    jogador.x = 100;
    jogador.y = height / 2;
  }
}

function displayInventario() {
  fill(0);
  textSize(24);
  text("Inventário:", 20, 30);
  for (let i = 0; i < jogador.inventario.length; i++) {
    text(jogador.inventario[i], 20, 60 + i * 30);
  }
}

function keyPressed() {
  if (keyCode === UP_ARROW) {
    jogador.y -= jogador.speed;
  }
  if (keyCode === DOWN_ARROW) {
    jogador.y += jogador.speed;
  }
  if (keyCode === RIGHT_ARROW) {
    jogador.x += jogador.speed;
  }
  if (keyCode === LEFT_ARROW) {
    jogador.x -= jogador.speed;
  }
}
